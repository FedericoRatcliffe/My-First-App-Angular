
//PROPIAMENTE ANGULAR SE DIVIDE EN MODULOS
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';

//SE IMPORTA EL NUEVO COMPONENTE PARA PODER USARLO EN LA APP
import { ServerComponent } from './server/server.component';
import { ServersComponent } from './servers/servers.component';



@NgModule({
  declarations: [
    AppComponent,
    //HAY QUE DECIRLE A ANGULAR QUE EL COMPONENTE NUEVO EXISTE
    ServerComponent,
    ServersComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})


export class AppModule { }
